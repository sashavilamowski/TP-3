﻿// See https://aka.ms/new-console-template for more information
using System.Collections.Generic;
int rta=0; 
do{
    Console.WriteLine("1.Nueva Inscripción, 2.Obtener Estadísticas del Evento, 3. Buscar Cliente, 4. Cambiar entrada de un Cliente, 5. Salir");
    rta=Funciones.IngresarEntero("Ingrese la opción: ");
    switch(rta){
        case 1:
        inscribirCliente();
        break;
        case 2:
        obtenerEstadisticas();
        break;
        case 3:
        buscarcliente();
        break;
        case 4:
        cambiarentrada();
        break;
    }
}while(rta!=5);

void  verificartipoEntrada(int tipoentrada){
    bool devolver=false;
    devolver=tipoentrada==1|| tipoentrada==2||tipoentrada==3||tipoentrada==4;
    if (!devolver){
        tipoentrada=Funciones.IngresarEntero("Ingrese 1 para Dia 1, 2 para Dia 2, 3 para Dia 3 o 4 para FullPass");
        verificartipoEntrada(tipoentrada);
    }
}
void  inscribirCliente(){
    int totalabonado=0;
    int dni=Funciones.IngresarEntero("Ingrese su DNI: ");
    string nombre=Funciones.IngresarTexto("Ingrese su Nombre: ");
    string apellido=Funciones.IngresarTexto("Ingrese su apellido: ");
    DateTime fechainscripcion=Funciones.IngresarFecha("Ingrese la fecha de inscripción: ");
    int tipoentrada=Funciones.IngresarEntero("Ingrese 1 para Dia 1, 2 para Dia 2, 3 para Dia 3 o 4 para FullPass: ");
    verificartipoEntrada(tipoentrada);
    switch (tipoentrada){
        case 1:
        totalabonado=15000;
        break;
        case 2:
        totalabonado=30000;
        break;
        case 3:
        totalabonado=10000;
        break;
        case 4:
        totalabonado=40000;
        break;
    }
    Cliente NuevoCli = new Cliente(dni,apellido,nombre,fechainscripcion,tipoentrada,totalabonado);
    Ticketera.AgregarCliente(NuevoCli);
}
void obtenerEstadisticas(){
     List<string>listaestadisticas=new List<string> ();
     listaestadisticas=Ticketera.EstadisticasTicketera();
     foreach(string item in listaestadisticas)
     {
        Console.WriteLine(item);
     }
}
void buscarcliente(){
    Cliente cliente=null;
    int idIngresado=Funciones.IngresarEntero("Ingrese el ID de la entrada que desea buscar: ");
    cliente=Ticketera.BuscarCliente(idIngresado);
    Console.WriteLine(cliente.DNI + " " + cliente.Apellido+ " "+ cliente.Nombre+" "+cliente.FechaInscripcion+" "+cliente.TipoEntrada+" "+cliente.TotalAbonado);
}
void cambiarentrada(){
    int idIngresado=Funciones.IngresarEntero("Ingrese el ID de la entrada que desea cambiar: ");
    int tipoIngresado=Funciones.IngresarEntero("Ingrese el tipo por el que desea cambiar su entrada (1,2,3 o 4): ");
    int totalCambio=0;
    switch (tipoIngresado){
        case 1:
        totalCambio=15000;
        break;
        case 2:
        totalCambio=30000;
        break;
        case 3:
        totalCambio=10000;
        break;
        case 4:
        totalCambio=40000;
        break;
}
bool sePuedeCambiar=Ticketera.CambiarEntrada(idIngresado,tipoIngresado,totalCambio);
Console.WriteLine(sePuedeCambiar);
}