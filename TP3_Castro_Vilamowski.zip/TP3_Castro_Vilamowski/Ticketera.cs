static class Ticketera{
    static private Dictionary<int,Cliente> DicClientes = new Dictionary<int,Cliente>();
    static private int UltimoIDEntrada=0;
    static public int DevolverUltimoID(){
        
        return UltimoIDEntrada;
    }
    static public int AgregarCliente(Cliente Cliente){
        UltimoIDEntrada++;
        DicClientes.Add(UltimoIDEntrada,Cliente);
        return UltimoIDEntrada;
    }
    static public Cliente BuscarCliente(int idIngresado){
        Cliente devolver=null;
            if ( DicClientes.ContainsKey(idIngresado)){
                devolver=DicClientes[idIngresado];
            }else {
                Console.WriteLine("Aún no hay clientes ingresados");
            }
            return devolver;
        }
    
    static public bool CambiarEntrada(int idIngresado,int tipoIngresado,int totalCambio){
        bool devolver=false;
        if(DicClientes.ContainsKey(idIngresado)){
            if (totalCambio>DicClientes[idIngresado].TotalAbonado){
               DicClientes[idIngresado].TipoEntrada=tipoIngresado;
               DicClientes[idIngresado].TotalAbonado=totalCambio;
               devolver=true;
            }
        }
        return devolver;
    }
    static public List <string> EstadisticasTicketera(){
        int acum1=0,acum2=0,acum3=0,acum4=0,acumTotal=0;
        List<string>listaEstadisticas=new List<string> ();
Console.WriteLine(UltimoIDEntrada);
       if (UltimoIDEntrada>0){
            listaEstadisticas.Add("La cantidad de clientes inscriptos es "+ UltimoIDEntrada);
            float porcentaje1=0,porcentaje2=0,porcentaje3=0,porcentaje4=0;
            int cont1=0,cont2=0,cont3=0,cont4=0;
            foreach(int ID in DicClientes.Keys){
                switch (DicClientes[ID].TipoEntrada){
                    case 1:
                    cont1++;
                    acum1+=15000;
                    break;
                    case 2:
                    cont2++;
                    acum2+=30000;
                    break;
                    case 3:
                    cont3++;
                    acum3+=10000;
                    break;
                    case 4:
                    cont4++;
                    acum4+=40000;
                    break;
                }
            }
            acumTotal=acum1+acum2+acum3+acum4;
            porcentaje1=cont1*100/UltimoIDEntrada;
            porcentaje2=cont2*100/UltimoIDEntrada;
            porcentaje3=cont3*100/UltimoIDEntrada;
            porcentaje4=cont4*100/UltimoIDEntrada;
            listaEstadisticas.Add("El porcentaje de tipo 1 es "+ porcentaje1+", el porcentaje de tipo 2 es "+ porcentaje2+", el porcentaje de tipo 3 es "+ porcentaje3+", el porcentaje de tipo 4 es "+ porcentaje4);
            listaEstadisticas.Add("La recaudación del día 1 es $"+acum1+", la recaudación del día 2 es $"+acum2+", la recaudación del día 3 es $"+acum3+", la recaudación del día 4 es $"+acum4);
            listaEstadisticas.Add("La recaudación total es $"+acumTotal);
        }
        else{
            listaEstadisticas.Add("Aún no se anotó nadie");
        }
        return listaEstadisticas;
    }
}